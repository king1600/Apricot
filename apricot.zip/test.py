import asyncio
from apricot.client import ApricotSession

async def main(loop):
    async with ApricotSession() as sess:
        url = "http://api.urbandictionary.com/v0/define?term=orange"
        url = "http://httpbin.org/stream/3"
        url = "http://httpbin.org/gzip"
        url = "http://httpbin.org/encoding/utf8"
        url = "http://httpbin.org/delay/3"
        url = "http://httpbin.org/stream-bytes/32"
        url = "http://httpbin.org/redirect-to?url=http://httpbin.org/ip"
        url = "http://google.com/humans.txt"
        url = "http://httpbin.org/absolute-redirect/5"
        url = "http://httpbin.org/cookies/set?test=me"
        response = await sess.get(url)

        # display results
        print("{0.version} {0.status} {0.reason}".format(response))
        print("\nText: {0.text}\n\nBody: {0.body}".format(response))
        print("\nHeaders: {0.headers}".format(response))
        print("\nJSON: {0.json}\n\nType: {0.content_type}".format(response))

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(loop))
    loop.close()